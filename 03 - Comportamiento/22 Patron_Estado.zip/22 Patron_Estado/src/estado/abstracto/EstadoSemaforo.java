package estado.abstracto;

public abstract class EstadoSemaforo{
    public abstract String mostrar();
}