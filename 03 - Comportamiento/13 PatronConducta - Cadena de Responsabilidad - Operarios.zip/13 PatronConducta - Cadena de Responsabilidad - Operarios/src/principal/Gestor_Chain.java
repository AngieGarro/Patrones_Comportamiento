package principal;

import java.util.ArrayList;
import java.util.List;

import chain.abstracto.ManejadorOperaciones;
import chain.concreto.Gerente;
import chain.concreto.Operario;
import chain.concreto.Supervisor;

public class Gestor_Chain {
	private List<Mensaje> Mensajes;
	private ManejadorOperaciones Gerente;

	public Gestor_Chain(){
		Mensajes = new ArrayList<Mensaje> ();
	}
	
	private ManejadorOperaciones configurarCadena() {
		ManejadorOperaciones LocalOperario = new Operario();
	    ManejadorOperaciones LocalSupervisor = new Supervisor();
	    ManejadorOperaciones LocalGerente = new Gerente();
    	
	    LocalGerente.setColaborador(LocalSupervisor);
    	LocalSupervisor.setColaborador(LocalOperario);
    	
    	return LocalGerente;
	}
	
	
	public void IniciarProceso() {
		Gerente = configurarCadena();
	}
	
	public void Ejecutar_Mensaje() {
		for(Mensaje mensaje : Mensajes){
        	Gerente.ejecutarOrden(mensaje);
	    }
	}
	
	public void AgregarMensaje(String pPara, String pMensaje) {
		Mensajes.add(new Mensaje(pPara, pMensaje));		
	}
}
