package chain.concreto;

import chain.abstracto.*;
import principal.Mensaje;

public class Supervisor extends ManejadorOperaciones{

	@Override
	public void ejecutarOrden(Mensaje mensaje) {

        if (mensaje.getPara().equals("Supervisor")) {
            System.out.println(mensaje.getContenido()+ " Att: El Mega Supervisor");
            if(mensaje.getContenido().equals("Saltar"))
            	Saltar();
        }else if (_colaborador != null)
            _colaborador.ejecutarOrden(mensaje);
		
	}

	public void Saltar() {
		System.out.println("estoy saltando como un supervisor");
	}
}
