package chain.concreto;

import chain.abstracto.*;
import principal.Mensaje;

public class Gerente extends ManejadorOperaciones{

	@Override
	public void ejecutarOrden(Mensaje mensaje) {
        if (mensaje.getPara().equals("Gerente"))
            System.out.println(mensaje.getContenido() + ". Atte: Gerente");
        else if (_colaborador != null)
            _colaborador.ejecutarOrden(mensaje);
		
	}

}
