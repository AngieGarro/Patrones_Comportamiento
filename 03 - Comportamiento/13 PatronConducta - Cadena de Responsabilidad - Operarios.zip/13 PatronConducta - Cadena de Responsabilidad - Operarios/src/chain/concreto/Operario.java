package chain.concreto;

import chain.abstracto.*;
import principal.Mensaje;

public class Operario extends ManejadorOperaciones{

	@Override
	public void ejecutarOrden(Mensaje mensaje) {

        if (mensaje.getPara().equals("Operario"))
            System.out.println(mensaje.getContenido() + " Att:Operario");
        else if (_colaborador != null)
            _colaborador.ejecutarOrden(mensaje);
        	else
        	System.out.println(mensaje.getPara() +" no puede hacer la accion: " + mensaje.getContenido() +" ya que no esta en la cadena ");
        	
		
	}

}
