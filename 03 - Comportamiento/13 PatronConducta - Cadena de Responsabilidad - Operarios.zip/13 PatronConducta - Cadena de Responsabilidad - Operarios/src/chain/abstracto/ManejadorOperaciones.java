package chain.abstracto;

import principal.Mensaje;

public abstract class ManejadorOperaciones {
	protected ManejadorOperaciones _colaborador;
	
	public void setColaborador(ManejadorOperaciones pColaborador){
		 this._colaborador = pColaborador;
	}

	public abstract void ejecutarOrden(Mensaje mensaje);
}
