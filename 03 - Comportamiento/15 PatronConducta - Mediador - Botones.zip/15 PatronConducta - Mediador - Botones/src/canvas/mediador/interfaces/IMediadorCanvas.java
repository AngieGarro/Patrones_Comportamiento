package canvas.mediador.interfaces;

public interface IMediadorCanvas {
	// -------------------------------
	 public void pintar(String pM);
	 public void borrar(String pM);
	 public void recortar(String pM);
	 public String mostrarHistorial();
}
