package principal;

public class main_mediadior {

	public static void main(String[] args) {
		gestor_mediadores gm = new gestor_mediadores();
		//gm.ejemplo_1();
		gm.ejemplo_Cuadro_de_texto();
		gm.ejemplo_Canvas();
	}

}
