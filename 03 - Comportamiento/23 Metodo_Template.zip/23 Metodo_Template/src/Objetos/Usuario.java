package Objetos;

public class Usuario {
	private String User;
	public Usuario(String user, String pass) {
		setUser( user);
		setPass( pass);
	}
	private String Pass;
	
	public String getUser() {
		return User;
	}
	public void setUser(String user) {
		User = user;
	}
	public String getPass() {
		return Pass;
	}
	public void setPass(String pass) {
		Pass = pass;
	}
}
