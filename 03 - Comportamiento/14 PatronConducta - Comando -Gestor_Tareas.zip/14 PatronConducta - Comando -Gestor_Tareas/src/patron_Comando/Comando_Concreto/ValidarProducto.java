package patron_Comando.Comando_Concreto;

import base.Producto;
import patron_Comando.Comando_Abstracto.TareaProducto;

public class ValidarProducto implements TareaProducto{

	@Override
	public void ejecutar(Producto producto) {
		if (producto.getPrecio() < 101)
			System.out.println("producto valido, precio: " + producto.getPrecio());
		else
			System.out.println("producto invalido." );
	}

}
