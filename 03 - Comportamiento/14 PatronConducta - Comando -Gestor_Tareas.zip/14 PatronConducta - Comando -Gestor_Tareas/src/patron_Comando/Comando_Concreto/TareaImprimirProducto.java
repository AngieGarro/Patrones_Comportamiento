package patron_Comando.Comando_Concreto;

import base.Producto;
import patron_Comando.Comando_Abstracto.TareaProducto;

public class TareaImprimirProducto implements TareaProducto{

	@Override
	public void ejecutar(Producto producto) {
		System.out.println(producto.getNombre());
	    System.out.println(producto.getId());
	    System.out.println(producto.getPrecio());
	}

}
