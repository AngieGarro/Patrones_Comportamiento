package patron_Comando.Comando_Concreto;

import java.util.ArrayList;
import java.util.List;

import base.Producto;
import patron_Comando.Comando_Abstracto.TareaProducto;

public class ManejadorTarea implements TareaProducto{
	private List<TareaProducto> lista= new ArrayList<TareaProducto>();
	  
	public void addTarea(TareaProducto tarea) {
		lista.add(tarea);
	}

	@Override
	public void ejecutar(Producto producto) {
		lista.forEach((t)->t.ejecutar(producto));
	}
}
