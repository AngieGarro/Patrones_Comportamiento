package patron_Comando.Comando_Concreto;

import base.Producto;
import patron_Comando.Comando_Abstracto.TareaProducto;

public class TareaEnvioCorreo implements TareaProducto{

	@Override
	public void ejecutar(Producto producto) {
		System.out.println(producto.getNombre() +" enviado por correo.") ;
	}

}
