package patron_Comando.Comando_Abstracto;

import base.Producto;

public interface TareaProducto {
	public abstract void ejecutar(Producto producto);
}
