package patron_Comando.Principal;

public class Principal {

	public static void main(String[] args) {
		Gestor_Comando GC = new Gestor_Comando();
		GC.InitialProcess();
	}

}
