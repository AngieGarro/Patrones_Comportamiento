package patron_Comando.Principal;

import base.Producto;
import patron_Comando.Comando_Abstracto.TareaProducto;

public class GestorTareas {
	public void ejecutar (TareaProducto tarea, Producto p) {
		tarea.ejecutar(p);
	}
}
