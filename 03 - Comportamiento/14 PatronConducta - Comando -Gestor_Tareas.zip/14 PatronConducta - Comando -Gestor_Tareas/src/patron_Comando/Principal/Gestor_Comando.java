package patron_Comando.Principal;

import base.Producto;
import patron_Comando.Comando_Abstracto.TareaProducto;
import patron_Comando.Comando_Concreto.ManejadorTarea;
import patron_Comando.Comando_Concreto.TareaEnvioCorreo;
import patron_Comando.Comando_Concreto.ValidarProducto;
import patron_Comando.Comando_Concreto.TareaImprimirProducto;

public class Gestor_Comando {

	public void ejecutar (TareaProducto tarea, Producto p) {
		tarea.ejecutar(p);
	}
	
	public void InitialProcess() {
		ManejadorTarea st = new ManejadorTarea();
		st.addTarea(new ValidarProducto());
	    st.addTarea(new TareaEnvioCorreo());
	    
	    ManejadorTarea st2 = new ManejadorTarea();
		st2.addTarea(new ValidarProducto());
		
		ManejadorTarea st3 = new ManejadorTarea();
		st3.addTarea(new TareaImprimirProducto());
	    
		ManejadorTarea st4 = new ManejadorTarea();
		st4.addTarea(new ValidarProducto());
	    st4.addTarea(new TareaEnvioCorreo());
	    st4.addTarea(new TareaImprimirProducto());
	    
	    GestorTareas gt= new GestorTareas();
	    
	    System.out.println("Super tarear ST");
	    ejecutar(st, new Producto(1,"Celular ",100));
	    System.out.println("");
	    ejecutar(st, new Producto(2,"Tableta ",50));
	    System.out.println("");
	    ejecutar(st, new Producto(3,"Computadora ",200));
	    System.out.println("\n");
	    
		System.out.println("\nSuper tarear ST2");
		ejecutar(st2, new Producto(1,"Celular ",100));
		System.out.println("");
		ejecutar(st2, new Producto(2,"Tableta ",50));
		System.out.println("");
		ejecutar(st2, new Producto(3,"Computadora ",200));
		System.out.println("\n");
	    
	    System.out.println("\nSuper tarear ST3");
		ejecutar(st3, new Producto(007,"James Bond ",1996));
		
		System.out.println("\nSuper tarear ST4");
		ejecutar(st4, new Producto(2021,"Somos lo mas especial del siglo",45));
	}
}
