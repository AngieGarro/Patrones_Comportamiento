package interfaces;

import interprete.Context;

public interface Expression{
    public abstract void interpret(Context context);
}
