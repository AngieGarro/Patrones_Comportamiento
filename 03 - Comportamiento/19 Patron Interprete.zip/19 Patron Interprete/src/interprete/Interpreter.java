 package interprete;

import java.util.ArrayList;

import interfaces.Expression;

public class Interpreter{
    public static void main(String[] args){
    	ArrayList aNumeros = new ArrayList();
		ArrayList aOperaciones = new ArrayList();
        
            
        aNumeros.add("dos");
        aNumeros.add("tres");
        aNumeros.add("cuatro");
        aNumeros.add("cinco");
        
        aOperaciones.add("mas");
        aOperaciones.add("mas");
        aOperaciones.add("menos");
        
        obtener_resultado(aNumeros.get(0).toString(), aNumeros.get(1).toString(),aOperaciones.get(0).toString()); 
        obtener_resultado(aNumeros.get(1).toString(), aNumeros.get(2).toString(),aOperaciones.get(1).toString()); 
        obtener_resultado(aNumeros.get(2).toString(), aNumeros.get(3).toString(),aOperaciones.get(2).toString()); 
    }
    
    private static void obtener_resultado(String pNum1, String pNum2, String pOper ) {
    	Context interprete = new Context();
    	agregar_calcular(interprete,pNum1);
    	interprete.setOperation(pOper);
    	agregar_calcular(interprete,pNum2);
    	
        System.out.println("El resultado de la interpretación es " + interprete.getResult());
    }
    
    private static void agregar_calcular(Context pInterprete, String pNum1) {
    	pInterprete.setOperator(pInterprete.getInteger(pNum1));
    	pInterprete.calculate();
    }
    
    
}