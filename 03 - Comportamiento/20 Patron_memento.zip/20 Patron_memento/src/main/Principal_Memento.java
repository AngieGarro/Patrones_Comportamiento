package main;

public class Principal_Memento {
	static Gestor_Memento Gestor;
	 public static void main(String[] args){
		 Gestor = new Gestor_Memento ("Pedro", "Gil Mena");
		 NombrePersona();
		    
		 Gestor.Cambiar_Nombre("Lucia");
		 Gestor.Cambiar_Apellido("Fernandez");
		 NombrePersona();
		 
		 Gestor.Actualizar_Memento();

		 Print( "\nCreando un memento:\n");
		 
		 Gestor.Cambiar_Nombre("Michael");
		 Gestor.Cambiar_Apellido("Jordan");
		 NombrePersona();
		 
		 Gestor.Cambiar_Nombre("Ines");
		 Gestor.Cambiar_Apellido("Sanchez");
		 NombrePersona();
		 
		 Gestor.Cambiar_Nombre("Joconda");
		 Gestor.Cambiar_Apellido("Julitrillos");
		 NombrePersona();
		 
		 Print( "\nPedimos el ultimo memento creado: (control Z)\n");
		 Gestor.Devolver_Memento();
		 NombrePersona();
	        
	 }
	 private static void Print( String pText) {
		 System.out.println(pText);
	 }
	 
	 private static void NombrePersona() {
		 Print("Nombre completo: [" + Gestor.Obtener_Nombre() + " " + Gestor.Obtener_Apellidos() + "]");
	 }
}
/******************************************************
*TAREA:
* - Crear un objeto Persona.
* - Cambiar el Originator para mantener un objeto persona.
* - Agregar un arreglo de Mementos. (agregar y devolver 
* de aquí)
*******************************************************/