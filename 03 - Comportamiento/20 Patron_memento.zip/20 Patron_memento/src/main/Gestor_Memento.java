package main;

import memento.Caretaker;
import memento.Originator;

public class Gestor_Memento {
	private Originator Creador; 
	private Caretaker Vigilante;
	
	//private Persona per1;
	public Gestor_Memento(String pNombre, String pApellido){
		Creador = new Originator(pNombre, pApellido);
		Vigilante = new Caretaker();
		Actualizar_Memento();
	}
	
	public void Actualizar_Memento() {
		Vigilante.setMemento( Creador.createMemento() );
	}
	
	public String Obtener_Nombre() {
		return Creador.getNombre();
	}
	
	public String Obtener_Apellidos() {
		return Creador.getApellidos();
	}
	
	public void Cambiar_Nombre(String pText) {
		Creador.setNombre(pText);
	}
	
	
	public void Cambiar_Apellido(String pText) {
		Creador.setApellidos(pText);
	}
	
	public void Devolver_Memento() {
		Creador.setMemento( Vigilante.getMemento() );
	}
	
	//public 
}
