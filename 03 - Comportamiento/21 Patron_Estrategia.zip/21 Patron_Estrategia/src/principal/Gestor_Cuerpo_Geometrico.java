package principal;

import java.util.ArrayList;

import strategy.base.AbstractArea;
import strategy.clases.derivadas.*;
import strategy.implementacion.CuerpoGeometrico;
import util.excepciones.*;

public class Gestor_Cuerpo_Geometrico {
	private ArrayList<CuerpoGeometrico> array_figuras;
	
	Gestor_Cuerpo_Geometrico(){
		array_figuras = new ArrayList<CuerpoGeometrico>();
	}

    public void nueva_figura_geometrica(float radio) throws PoligonoNoExisteException, PoligonoNoSoportadoException {
    	agregar_array( new CuerpoGeometrico(radio));
    }
    
    public void nueva_figura_geometrica(float radio, int lados) throws PoligonoNoExisteException, PoligonoNoSoportadoException, ConstructorIncorrectoException {
    	agregar_array(new CuerpoGeometrico(radio, lados));
    }
    
    public void nueva_figura_geometrica(float base, float altura, int lados) throws PoligonoNoExisteException, PoligonoNoSoportadoException {
    	agregar_array(new CuerpoGeometrico(base,altura, lados));
    }
    
    private void agregar_array(CuerpoGeometrico pCG) throws PoligonoNoExisteException, PoligonoNoSoportadoException {
    	esoger_estrategia(pCG);
    	array_figuras.add(pCG);
    }
    
    private void esoger_estrategia(CuerpoGeometrico pCG) throws PoligonoNoExisteException, PoligonoNoSoportadoException {
    	AbstractArea _estrategia;
		if (pCG.isCirculo()) {
			_estrategia = new AreaCircular(pCG.getRadio());
		} else if (pCG.isTriangulo()) {
		    _estrategia = new AreaTriangulo(pCG.getBase(), pCG.getAltura());
		} else if (pCG.isRectangulo()) {
		    _estrategia = new AreaRectangulo(pCG.getBase(), pCG.getAltura());
		} else if (pCG.isPoligonoRegular()) {
		    _estrategia = new AreaPoligonoRegular(pCG.getLados(), pCG.getRadio());
		} else if (pCG.getLados() == 2 || pCG.getLados()== 0) {
		    throw new PoligonoNoExisteException();
		} else {
		    throw new PoligonoNoSoportadoException();
		}
		pCG.set_estrategia(_estrategia);
	}
    
    public String impimir_area(int pId_figura) {
    	return this.array_figuras.get(pId_figura).imprimeArea();
    }

	public int cantidad_figuras() {
		return this.array_figuras.size();
	}
    
    
}
