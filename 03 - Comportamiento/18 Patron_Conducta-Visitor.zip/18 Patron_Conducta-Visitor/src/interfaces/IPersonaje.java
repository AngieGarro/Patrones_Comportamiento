package interfaces;

public interface IPersonaje {
	public void accept(IVisitor visitor);
}
