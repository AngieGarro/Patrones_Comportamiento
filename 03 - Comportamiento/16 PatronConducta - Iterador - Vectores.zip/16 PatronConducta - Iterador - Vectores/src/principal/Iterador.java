 package principal;

public interface Iterador {
	public Object primero();
    public Object siguiente();
    public boolean hayMas();
    public Object actual();
}
