package principal;

public interface Agregado {
	public Iterador getIterador();
}
