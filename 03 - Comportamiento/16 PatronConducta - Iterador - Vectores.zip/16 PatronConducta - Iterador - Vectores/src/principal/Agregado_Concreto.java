package principal;

import java.util.Vector;

public class Agregado_Concreto implements Agregado {
	protected Vector aDatos = new Vector();
	@Override
	public Iterador getIterador(){
        return new Iterador_Concreto(this);
    }
	
	 public Agregado_Concreto() {
	 	this.llenar();
	 }
	 
	 public void llenar() {
		this.aDatos.add( new String("JOSE") );
        this.aDatos.add( new String("MARTA") );
        this.aDatos.add( new String("ANTONIO") );
        this.aDatos.add( new String("ROMINA") );
        this.aDatos.add( 10 );
        this.aDatos.add( 2021 );
        this.aDatos.add( 20.21 );
        this.aDatos.add( false );
	 }
	 
}
