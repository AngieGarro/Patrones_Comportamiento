package principal;

public class principal {
	
	private static Agregado_Concreto agregado;
	private static Iterador iterador;
	
	public static void main(String[] args) {
		try {
			inicializar();
			
            String obj = (String) iterador.primero();
            imprimir( obj, "Mostrar el elemento #1" );
         
            obj=avanzar(2);
            imprimir( obj, "Mover dos posición adelante" );
        
            iterador.primero();
            imprimir( ahoraSoy(), "Primero en la lista" ); 
            
            System.out.println( "\nImprimimos todos:" );
            imprimirDesdeDondeEstoyEnAdelante();
            
            iterador.primero();
            obj=avanzar(3);
            imprimir( obj, "\nMover tres posición adelante" );
            
            System.out.println( "\nImprimimos todos:" );
            imprimirDesdeDondeEstoyEnAdelante();
            
            
            
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}

	}

	private static void inicializar() {
        agregado = new Agregado_Concreto(); 	// Crear el objeto agregado que contiene la lista (un vector en este ejemplo)
        iterador = agregado.getIterador();		// Crear el objeto iterador para recorrer la lista
	}
	
	private static void imprimir(Object pObj, String pMsg) {
		System.out.println( pMsg );
		System.out.println( pObj +"\n");
	}
	
	private static String avanzar(int pVeces) {
		
		for (int i=0; i < pVeces; i++) {
			iterador.siguiente();
		}
		
		return ahoraSoy();
	}
	
	private static String ahoraSoy() {
		return (String) iterador.actual();
	}
	
	private static void imprimirDesdeDondeEstoyEnAdelante() {
		while( iterador.hayMas() == true ) {
            System.out.println( iterador.siguiente() );
        }
	}
}